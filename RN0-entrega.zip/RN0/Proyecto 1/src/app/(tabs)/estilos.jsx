import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { colors } from '../../../constants/theme';

// Contrasta con Inicio mediante una composición oscura, asimétrica y editorial.
export default function StylesScreen() {
  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar style="light" />
      <View style={styles.orbLavender} />
      <View style={styles.orbMint} />
      <View style={styles.content}>
        <Text style={styles.kicker}>MISMO PROYECTO · OTRO ESTILO</Text>
        <Text style={styles.title}>Crear también es elegir.</Text>
        <View style={styles.rule} />
        <Text style={styles.body}>
          Color, escala, espacio y alineación cambian por completo la personalidad de una pantalla.
        </Text>
        <View style={styles.tags}>
          <Text style={styles.tag}>StyleSheet</Text>
          <Text style={styles.tag}>Flexbox</Text>
          <Text style={styles.tag}>Responsive</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    overflow: 'hidden',
    backgroundColor: colors.navy,
  },
  orbLavender: {
    position: 'absolute',
    top: -75,
    right: -50,
    width: 230,
    height: 230,
    borderRadius: 115,
    backgroundColor: colors.lavender,
    opacity: 0.9,
  },
  orbMint: {
    position: 'absolute',
    bottom: 50,
    left: -90,
    width: 190,
    height: 190,
    borderRadius: 95,
    backgroundColor: colors.mint,
    opacity: 0.75,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    maxWidth: 620,
    paddingHorizontal: '9%',
  },
  kicker: {
    color: colors.mint,
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
  },
  title: {
    maxWidth: 440,
    marginTop: 18,
    color: colors.white,
    fontSize: 48,
    fontWeight: '300',
    lineHeight: 54,
    letterSpacing: -1.5,
  },
  rule: {
    width: 64,
    height: 5,
    marginVertical: 26,
    borderRadius: 3,
    backgroundColor: colors.lavender,
  },
  body: {
    maxWidth: 430,
    color: '#CDD3E5',
    fontSize: 17,
    lineHeight: 27,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 9,
    marginTop: 28,
  },
  tag: {
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 18,
    overflow: 'hidden',
    color: colors.white,
    fontSize: 12,
    fontWeight: '700',
    backgroundColor: '#232B4D',
  },
});

// Este archivo exporta: StylesScreen (tab Estilos).
// Se usa en: src/app/(tabs)/_layout.jsx por enrutamiento de archivos.
// Importa de: constants/theme.js, Expo y React Native.
