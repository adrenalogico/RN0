import { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ComponentShowcaseCard } from '../../../components/ComponentShowcaseCard';
import { ScreenContainer } from '../../../components/ScreenContainer';
import { spacing } from '../../../constants/theme';
import { useAppTheme } from '../../../hooks/useAppTheme';

// Reúne los bloques estructurales, el texto y las entradas más frecuentes.
export default function FoundationsScreen() {
  const { colors } = useAppTheme();
  const [name, setName] = useState<string>('');
  const [enabled, setEnabled] = useState<boolean>(true);

  return (
    <ScreenContainer
      eyebrow="01 · FUNDAMENTOS"
      title="Layout, texto y entradas"
      description="Estas piezas forman la estructura visual y permiten mostrar o capturar información.">
      <ComponentShowcaseCard
        title="View"
        description="Contenedor fundamental para agrupar elementos, aplicar Flexbox, fondo, borde y espaciado.">
        <View style={styles.viewRow}>
          <View style={[styles.colorBlock, { backgroundColor: colors.primary }]} />
          <View style={[styles.colorBlock, { backgroundColor: colors.accent }]} />
          <View style={[styles.colorBlock, { backgroundColor: colors.success }]} />
        </View>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="SafeAreaView"
        description="Evita que el contenido quede debajo del notch, esquinas redondeadas o barras del sistema."
        note="El SafeAreaView del núcleo fue deprecado. Esta demo usa el reemplazo vigente de react-native-safe-area-context.">
        <SafeAreaView style={[styles.safeDemo, { borderColor: colors.primary }]} edges={['top']}>
          <Text style={[styles.centerText, { color: colors.text }]}>Contenido dentro del área segura</Text>
        </SafeAreaView>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="ScrollView"
        description="Permite desplazar contenido cuando supera el espacio visible; renderiza todos sus hijos de una vez."
        note="Esta pantalla completa es un ScrollView: desplazala para comprobar su comportamiento.">
        <Text style={[styles.centerText, { color: colors.textMuted }]}>↕ Desplazamiento vertical activo</Text>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="KeyboardAvoidingView"
        description="Ajusta altura, posición o padding para que el teclado no tape los campos de entrada.">
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Escribí tu nombre"
            placeholderTextColor={colors.textMuted}
            style={[
              styles.input,
              { color: colors.text, borderColor: colors.border, backgroundColor: colors.surface },
            ]}
          />
        </KeyboardAvoidingView>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="Text"
        description="Muestra texto y permite anidar fragmentos con estilos o acciones diferentes.">
        <Text style={[styles.textDemo, { color: colors.text }]}>
          React Native combina <Text style={{ color: colors.primary, fontWeight: '900' }}>jerarquía</Text>{' '}
          y legibilidad.
        </Text>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="TextInput"
        description="Recibe texto del usuario y se controla con estado para validar o reutilizar el valor.">
        <View>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Tu nombre"
            placeholderTextColor={colors.textMuted}
            accessibilityLabel="Campo para escribir el nombre"
            style={[
              styles.input,
              { color: colors.text, borderColor: colors.border, backgroundColor: colors.surface },
            ]}
          />
          <Text style={[styles.inputResult, { color: colors.textMuted }]}>Hola, {name.trim() || 'visitante'}.</Text>
        </View>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="Switch"
        description="Representa una opción booleana, como activar notificaciones o una preferencia.">
        <View style={styles.switchRow}>
          <Text style={[styles.switchLabel, { color: colors.text }]}>
            Notificaciones {enabled ? 'activadas' : 'desactivadas'}
          </Text>
          <Switch
            value={enabled}
            onValueChange={setEnabled}
            trackColor={{ false: colors.border, true: colors.primarySoft }}
            thumbColor={enabled ? colors.primary : colors.textMuted}
          />
        </View>
      </ComponentShowcaseCard>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  viewRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  colorBlock: {
    flex: 1,
    height: 44,
    borderRadius: 12,
  },
  safeDemo: {
    minHeight: 64,
    justifyContent: 'center',
    borderTopWidth: 8,
    borderRadius: 12,
  },
  centerText: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
  input: {
    width: '100%',
    minHeight: 48,
    paddingHorizontal: spacing.md,
    borderWidth: 1,
    borderRadius: 13,
    fontSize: 15,
  },
  textDemo: {
    fontSize: 17,
    lineHeight: 25,
    textAlign: 'center',
  },
  inputResult: {
    marginTop: spacing.sm,
    fontSize: 13,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  switchLabel: {
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
  },
});

// Este archivo exporta: FoundationsScreen (tab Bases).
// Se usa en: src/app/(tabs)/_layout.tsx por enrutamiento de archivos.
// Importa de: tarjetas, contenedor, tema, hook, safe-area y React Native.
