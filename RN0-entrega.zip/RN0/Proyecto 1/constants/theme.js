// Reúne la paleta compartida para que las pantallas mantengan una base consistente.
export const colors = {
  ink: '#14213D',
  muted: '#5F6B7A',
  cream: '#FFF9EE',
  white: '#FFFFFF',
  coral: '#FF6B5E',
  navy: '#10162F',
  lavender: '#B9A7FF',
  mint: '#6EE7C7',
  line: '#E8DDCB',
};

// Este archivo exporta: colors (paleta de la aplicación).
// Se usa en: componentes y pantallas dentro de src/app.
// Importa de: ningún archivo del proyecto.
