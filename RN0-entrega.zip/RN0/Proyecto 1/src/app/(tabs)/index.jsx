import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { GreetingCard } from '../../../components/GreetingCard';
import { colors } from '../../../constants/theme';

// Presenta el saludo inicial en un lienzo luminoso y centrado.
export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar style="dark" />
      <View style={styles.backgroundAccent} />
      <View style={styles.content}>
        <Text style={styles.step}>RN0 · PASO 01</Text>
        <GreetingCard />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.cream,
  },
  backgroundAccent: {
    position: 'absolute',
    top: -70,
    right: -70,
    width: 210,
    height: 210,
    borderRadius: 105,
    backgroundColor: '#FFD9C9',
    opacity: 0.7,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    paddingHorizontal: '7%',
  },
  step: {
    width: '100%',
    maxWidth: 520,
    marginBottom: 12,
    color: colors.muted,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
});

// Este archivo exporta: HomeScreen (tab Inicio).
// Se usa en: src/app/(tabs)/_layout.jsx por enrutamiento de archivos.
// Importa de: components/GreetingCard.jsx, constants/theme.js, Expo y React Native.
