import { useState } from 'react';
import {
  Button,
  Pressable,
  StyleSheet,
  Text,
  TouchableHighlight,
  TouchableOpacity,
  View,
} from 'react-native';

import { ComponentShowcaseCard } from '../../../components/ComponentShowcaseCard';
import { ScreenContainer } from '../../../components/ScreenContainer';
import { spacing } from '../../../constants/theme';
import { useAppTheme } from '../../../hooks/useAppTheme';

// Compara cuatro formas nativas de responder a un toque.
export default function InteractionScreen() {
  const { colors } = useAppTheme();
  const [lastAction, setLastAction] = useState<string>('Todavía no presionaste ningún control.');

  const registerAction = (name: string) => setLastAction(`Última acción: ${name}`);

  return (
    <ScreenContainer
      eyebrow="02 · INTERACCIÓN"
      title="Botones y superficies táctiles"
      description="Todos responden a un toque, pero ofrecen distintos niveles de control visual.">
      <View style={[styles.result, { backgroundColor: colors.primarySoft }]}>
        <Text style={[styles.resultText, { color: colors.text }]}>{lastAction}</Text>
      </View>

      <ComponentShowcaseCard
        title="Button"
        description="Botón básico con apariencia propia de cada plataforma. Es rápido de usar y poco personalizable.">
        <Button title="Probar Button" color={colors.primary} onPress={() => registerAction('Button')} />
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="Pressable"
        description="Detecta estados como pressed y permite cambiar el estilo mientras se mantiene presionado.">
        <Pressable
          onPress={() => registerAction('Pressable')}
          accessibilityRole="button"
          style={({ pressed }) => [
            styles.customButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.65 : 1 },
          ]}>
          {({ pressed }) => (
            <Text style={styles.customButtonText}>{pressed ? 'Presionando…' : 'Probar Pressable'}</Text>
          )}
        </Pressable>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="TouchableOpacity"
        description="Reduce la opacidad al tocarlo. Es útil para controles personalizados con feedback sutil.">
        <TouchableOpacity
          activeOpacity={0.55}
          onPress={() => registerAction('TouchableOpacity')}
          style={[styles.outlineButton, { borderColor: colors.primary }]}>
          <Text style={[styles.outlineButtonText, { color: colors.primary }]}>Probar opacidad</Text>
        </TouchableOpacity>
      </ComponentShowcaseCard>

      <ComponentShowcaseCard
        title="TouchableHighlight"
        description="Muestra un color inferior al presionar; conviene cuando se necesita un resaltado evidente.">
        <TouchableHighlight
          underlayColor={colors.accent}
          onPress={() => registerAction('TouchableHighlight')}
          style={[styles.highlightButton, { backgroundColor: colors.surface, borderColor: colors.accent }]}>
          <Text style={[styles.outlineButtonText, { color: colors.text }]}>Probar resaltado</Text>
        </TouchableHighlight>
      </ComponentShowcaseCard>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  result: {
    padding: spacing.md,
    borderRadius: 16,
  },
  resultText: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
  customButton: {
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 14,
  },
  customButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  outlineButton: {
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderRadius: 14,
  },
  highlightButton: {
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 2,
    borderRadius: 14,
  },
  outlineButtonText: {
    fontSize: 15,
    fontWeight: '800',
  },
});

// Este archivo exporta: InteractionScreen (tab Acciones).
// Se usa en: src/app/(tabs)/_layout.tsx por enrutamiento de archivos.
// Importa de: tarjetas, contenedor, tema, hook y React Native.
