import { StatusBar } from 'expo-status-bar';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { spacing } from '../constants/theme';
import { useAppTheme } from '../hooks/useAppTheme';
import type { ScreenContainerProps } from '../types';

// Resuelve área segura, scroll, encabezado y tema para pantallas de contenido.
export function ScreenContainer({ eyebrow, title, description, children }: ScreenContainerProps) {
  const { colors, isDark } = useAppTheme();

  return (
    <SafeAreaView
      style={[styles.safeArea, { backgroundColor: colors.background }]}
      edges={['top', 'left', 'right']}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow}</Text>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
          <Text style={[styles.description, { color: colors.textMuted }]}>{description}</Text>
        </View>
        <View style={styles.content}>{children}</View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContent: {
    width: '100%',
    maxWidth: 760,
    alignSelf: 'center',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    paddingBottom: 110,
  },
  header: {
    paddingHorizontal: spacing.xs,
    marginBottom: spacing.lg,
  },
  eyebrow: {
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
  },
  title: {
    marginTop: spacing.xs,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -1,
  },
  description: {
    marginTop: spacing.sm,
    fontSize: 15,
    lineHeight: 23,
  },
  content: {
    gap: spacing.md,
  },
});

// Este archivo exporta: ScreenContainer (contenedor de categoría).
// Se usa en: Inicio, Fundamentos e Interacción.
// Importa de: constants/theme.ts, hooks/useAppTheme.ts, types/index.ts, Expo y React Native.
