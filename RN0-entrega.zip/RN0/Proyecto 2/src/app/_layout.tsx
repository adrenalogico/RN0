import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Instala el proveedor de áreas seguras y el navegador raíz.
export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
      </Stack>
    </SafeAreaProvider>
  );
}

// Este archivo exporta: RootLayout (layout raíz del catálogo).
// Se usa en: automáticamente por Expo Router.
// Importa de: expo-router y react-native-safe-area-context.
