import type { AppColors } from '../types';

// Paleta luminosa para ambientes con tema claro.
export const lightColors: AppColors = {
  background: '#F5F7FB',
  surface: '#FFFFFF',
  surfaceElevated: '#EEF2FF',
  text: '#172033',
  textMuted: '#61708A',
  primary: '#5B5FEF',
  primarySoft: '#E8E9FF',
  accent: '#FF8B5D',
  border: '#DDE3EE',
  success: '#17875D',
  danger: '#C94155',
};

// Paleta oscura equivalente, con contraste suficiente para lectura.
export const darkColors: AppColors = {
  background: '#0E1423',
  surface: '#171F31',
  surfaceElevated: '#212B42',
  text: '#F2F5FB',
  textMuted: '#AAB5C8',
  primary: '#A7A9FF',
  primarySoft: '#2D315D',
  accent: '#FFAA85',
  border: '#303B53',
  success: '#66D6A8',
  danger: '#FF8797',
};

// Escala de espaciado común para sostener el ritmo visual.
export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 24,
  xl: 32,
};

// Este archivo exporta: lightColors, darkColors y spacing.
// Se usa en: hooks/useAppTheme.ts, componentes y pantallas.
// Importa de: types/index.ts.
