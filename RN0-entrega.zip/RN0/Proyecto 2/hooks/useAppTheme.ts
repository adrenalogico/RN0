import { useEffect, useState } from 'react';
import { Platform, useColorScheme } from 'react-native';

import { darkColors, lightColors } from '../constants/theme';
import type { AppTheme } from '../types';

// Traduce el tema del sistema a la paleta tipada de la aplicación.
export function useAppTheme(): AppTheme {
  const systemColorScheme = useColorScheme();
  // En web, conserva el mismo tema del HTML estático hasta completar la hidratación.
  const [hasHydrated, setHasHydrated] = useState<boolean>(Platform.OS !== 'web');

  useEffect(() => {
    const hydrationTimer = setTimeout(() => setHasHydrated(true), 0);

    return () => clearTimeout(hydrationTimer);
  }, []);

  const resolvedColorScheme = hasHydrated ? systemColorScheme : 'light';
  const isDark = resolvedColorScheme === 'dark';

  return {
    isDark,
    colors: isDark ? darkColors : lightColors,
  };
}

// Este archivo exporta: useAppTheme (hook de tema claro/oscuro).
// Se usa en: layouts, componentes y pantallas del catálogo.
// Importa de: constants/theme.ts, types/index.ts y React Native.
