// Usa la configuración plana recomendada por Expo para TypeScript y React Native.
const { defineConfig, globalIgnores } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  globalIgnores(['dist/*', '.expo/*']),
  expoConfig,
]);

// Este archivo exporta: la configuración de ESLint.
// Se usa en: npm run lint.
// Importa de: eslint y eslint-config-expo.
