import { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ComponentShowcaseCard } from '../../../components/ComponentShowcaseCard';
import { spacing } from '../../../constants/theme';
import { useAppTheme } from '../../../hooks/useAppTheme';

// Demuestra estados transitorios, capas del sistema e imágenes.
export default function FeedbackScreen() {
  const { colors, isDark } = useAppTheme();
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [updatedAt, setUpdatedAt] = useState<string>('Deslizá hacia abajo para actualizar');

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setUpdatedAt(`Actualizado a las ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
      setRefreshing(false);
    }, 800);
  }, []);

  const showAlert = () => {
    Alert.alert('Alert en acción', 'Esta API abre un diálogo nativo del sistema.', [
      { text: 'Entendido', style: 'default' },
    ]);
  };

  return (
    <SafeAreaView
      style={[styles.safeArea, { backgroundColor: colors.background }]}
      edges={['top', 'left', 'right']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }>
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>04 · FEEDBACK Y MULTIMEDIA</Text>
          <Text style={[styles.title, { color: colors.text }]}>Comunicar lo que está pasando</Text>
          <Text style={[styles.description, { color: colors.textMuted }]}>
            Carga, confirmaciones, actualización, capas e imágenes ayudan a que la interfaz se explique sola.
          </Text>
        </View>

        <View style={styles.cards}>
          <ComponentShowcaseCard
            title="ActivityIndicator"
            description="Indica que una tarea está en curso cuando todavía no hay un progreso exacto para mostrar.">
            <View style={styles.inlineDemo}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.inlineText, { color: colors.text }]}>Cargando contenido…</Text>
            </View>
          </ComponentShowcaseCard>

          <ComponentShowcaseCard
            title="Modal"
            description="Presenta contenido por encima de la pantalla actual y concentra la atención en una tarea.">
            <Pressable
              onPress={() => setModalVisible(true)}
              accessibilityRole="button"
              style={[styles.actionButton, { backgroundColor: colors.primary }]}>
              <Text style={styles.actionButtonText}>Abrir modal</Text>
            </Pressable>
          </ComponentShowcaseCard>

          <ComponentShowcaseCard
            title="RefreshControl"
            description="Agrega el gesto pull-to-refresh a un ScrollView o FlatList."
            note="Arrastrá esta pantalla hacia abajo para ejecutar la actualización.">
            <Text style={[styles.centerText, { color: colors.text }]}>{updatedAt}</Text>
          </ComponentShowcaseCard>

          <ComponentShowcaseCard
            title="Alert"
            description="Es una API, no un componente visual: abre un diálogo nativo para avisos o confirmaciones.">
            <Pressable
              onPress={showAlert}
              accessibilityRole="button"
              style={[styles.outlineButton, { borderColor: colors.accent }]}>
              <Text style={[styles.outlineButtonText, { color: colors.text }]}>Mostrar alerta nativa</Text>
            </Pressable>
          </ComponentShowcaseCard>

          <ComponentShowcaseCard
            title="Image"
            description="Muestra imágenes locales o remotas y permite controlar su tamaño y modo de ajuste.">
            <View style={styles.imageDemo}>
              <Image
                source={require('../../../assets/images/icon.png')}
                resizeMode="cover"
                accessibilityLabel="Ícono local del catálogo"
                style={styles.image}
              />
              <View style={styles.imageCopy}>
                <Text style={[styles.imageTitle, { color: colors.text }]}>Recurso local</Text>
                <Text style={[styles.imageText, { color: colors.textMuted }]}>{'resizeMode="cover"'}</Text>
              </View>
            </View>
          </ComponentShowcaseCard>

          <ComponentShowcaseCard
            title="StatusBar"
            description="Controla la apariencia del texto y los íconos de la barra de estado del dispositivo.">
            <View style={[styles.statusDemo, { backgroundColor: colors.surface }]}>
              <Text style={[styles.statusTime, { color: colors.text }]}>9:41</Text>
              <View style={styles.statusIcons}>
                <View style={[styles.signal, { backgroundColor: colors.text }]} />
                <View style={[styles.signalWide, { backgroundColor: colors.text }]} />
              </View>
            </View>
          </ComponentShowcaseCard>
        </View>
      </ScrollView>

      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.surface }]}>
            <View style={[styles.modalIcon, { backgroundColor: colors.primarySoft }]}>
              <Text style={styles.modalEmoji}>✨</Text>
            </View>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Este contenido está en un Modal</Text>
            <Text style={[styles.modalText, { color: colors.textMuted }]}>
              La pantalla anterior sigue detrás y recuperará el foco al cerrar.
            </Text>
            <Pressable
              onPress={() => setModalVisible(false)}
              accessibilityRole="button"
              style={[styles.actionButton, { backgroundColor: colors.primary }]}>
              <Text style={styles.actionButtonText}>Cerrar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  content: {
    width: '100%',
    maxWidth: 760,
    alignSelf: 'center',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    paddingBottom: 110,
  },
  header: {
    paddingHorizontal: spacing.xs,
    marginBottom: spacing.lg,
  },
  eyebrow: {
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
  },
  title: {
    marginTop: spacing.xs,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -1,
  },
  description: {
    marginTop: spacing.sm,
    fontSize: 15,
    lineHeight: 23,
  },
  cards: {
    gap: spacing.md,
  },
  inlineDemo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.md,
  },
  inlineText: {
    fontSize: 14,
    fontWeight: '700',
  },
  actionButton: {
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    borderRadius: 14,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  centerText: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
  outlineButton: {
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderRadius: 14,
  },
  outlineButtonText: {
    fontSize: 15,
    fontWeight: '800',
  },
  imageDemo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  image: {
    width: 76,
    height: 76,
    borderRadius: 18,
  },
  imageCopy: {
    flex: 1,
  },
  imageTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  imageText: {
    marginTop: 4,
    fontSize: 13,
  },
  statusDemo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 12,
  },
  statusTime: {
    fontSize: 13,
    fontWeight: '900',
  },
  statusIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  signal: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  signalWide: {
    width: 18,
    height: 8,
    borderRadius: 4,
  },
  modalBackdrop: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    backgroundColor: 'rgba(5, 10, 20, 0.72)',
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    padding: spacing.lg,
    borderRadius: 26,
  },
  modalIcon: {
    width: 58,
    height: 58,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 18,
  },
  modalEmoji: {
    fontSize: 27,
  },
  modalTitle: {
    marginTop: spacing.md,
    fontSize: 23,
    fontWeight: '900',
  },
  modalText: {
    marginTop: spacing.sm,
    marginBottom: spacing.lg,
    fontSize: 14,
    lineHeight: 21,
  },
});

// Este archivo exporta: FeedbackScreen (tab Feedback).
// Se usa en: src/app/(tabs)/_layout.tsx por enrutamiento de archivos.
// Importa de: ComponentShowcaseCard, tema, hook, safe-area y React Native.
