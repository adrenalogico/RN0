import { StyleSheet, Text, View } from 'react-native';

import { ScreenContainer } from '../../../components/ScreenContainer';
import { spacing } from '../../../constants/theme';
import { useAppTheme } from '../../../hooks/useAppTheme';

const categories = [
  { icon: '▱', title: 'Fundamentos', detail: 'Layout, texto y entradas', count: '7 demos' },
  { icon: '✋', title: 'Interacción', detail: 'Botones y gestos', count: '4 demos' },
  { icon: '≡', title: 'Listas', detail: 'Datos planos y agrupados', count: '2 demos' },
  { icon: '✦', title: 'Feedback', detail: 'Estado, capas y multimedia', count: '6 demos' },
] as const;

// Funciona como mapa visual antes de explorar cada tab del catálogo.
export default function HomeScreen() {
  const { colors, isDark } = useAppTheme();

  return (
    <ScreenContainer
      eyebrow="CATÁLOGO RN · TYPESCRIPT"
      title="Componentes que construyen una app"
      description="Cada sección explica para qué sirve un componente nativo y permite verlo o probarlo en contexto.">
      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <Text style={[styles.heroGlyph, { color: isDark ? '#172033' : '#FFFFFF' }]}>▯</Text>
        <View style={styles.heroText}>
          <Text style={[styles.heroTitle, { color: isDark ? '#172033' : '#FFFFFF' }]}>19 ejemplos</Text>
          <Text style={[styles.heroDescription, { color: isDark ? '#2D3650' : '#ECECFF' }]}>Tipados, interactivos y organizados.</Text>
        </View>
      </View>

      <View style={styles.grid}>
        {categories.map((category) => (
          <View
            key={category.title}
            style={[styles.category, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.iconBox, { backgroundColor: colors.primarySoft }]}>
              <Text style={[styles.iconGlyph, { color: colors.primary }]}>{category.icon}</Text>
            </View>
            <Text style={[styles.categoryTitle, { color: colors.text }]}>{category.title}</Text>
            <Text style={[styles.categoryDetail, { color: colors.textMuted }]}>{category.detail}</Text>
            <Text style={[styles.count, { color: colors.primary }]}>{category.count}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.tip, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
        <Text style={[styles.tipGlyph, { color: colors.accent }]}>{isDark ? '☾' : '☀'}</Text>
        <Text style={[styles.tipText, { color: colors.textMuted }]}>
          El diseño responde automáticamente al modo {isDark ? 'oscuro' : 'claro'} configurado en el sistema.
        </Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  hero: {
    minHeight: 132,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: 24,
  },
  heroText: {
    flex: 1,
  },
  heroGlyph: {
    width: 44,
    fontSize: 44,
    fontWeight: '300',
    lineHeight: 50,
    textAlign: 'center',
  },
  heroTitle: {
    fontSize: 26,
    fontWeight: '900',
  },
  heroDescription: {
    marginTop: 4,
    fontSize: 14,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  category: {
    minWidth: 150,
    flexGrow: 1,
    flexBasis: '47%',
    padding: spacing.md,
    borderWidth: 1,
    borderRadius: 20,
  },
  iconBox: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 14,
  },
  iconGlyph: {
    fontSize: 24,
    fontWeight: '900',
    lineHeight: 28,
  },
  categoryTitle: {
    marginTop: spacing.md,
    fontSize: 17,
    fontWeight: '800',
  },
  categoryDetail: {
    minHeight: 40,
    marginTop: 4,
    fontSize: 13,
    lineHeight: 19,
  },
  count: {
    marginTop: spacing.sm,
    fontSize: 12,
    fontWeight: '800',
  },
  tip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    borderWidth: 1,
    borderRadius: 18,
  },
  tipText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 19,
  },
  tipGlyph: {
    width: 24,
    fontSize: 22,
    lineHeight: 26,
    textAlign: 'center',
  },
});

// Este archivo exporta: HomeScreen (portada del catálogo).
// Se usa en: src/app/(tabs)/_layout.tsx por enrutamiento de archivos.
// Importa de: components/ScreenContainer.tsx, tema, hook y React Native.
