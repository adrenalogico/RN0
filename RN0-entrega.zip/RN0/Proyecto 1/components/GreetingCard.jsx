import { StyleSheet, Text, View } from 'react-native';

import { colors } from '../constants/theme';

// Encapsula el saludo principal para poder reutilizarlo sin repetir estilos.
export function GreetingCard() {
  return (
    <View style={styles.card} accessible accessibilityLabel="Tarjeta de bienvenida Hola Mundo">
      <View style={styles.eyebrowRow}>
        <View style={styles.dot} />
        <Text style={styles.eyebrow}>MI PRIMERA VEZ EN EXPO</Text>
      </View>
      <Text style={styles.title}>Hola Mundo</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '100%',
    maxWidth: 520,
    padding: 28,
    borderRadius: 28,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.line,
    boxShadow: '0 12px 24px rgba(20, 33, 61, 0.10)',
    elevation: 5,
  },
  eyebrowRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 18,
  },
  dot: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: colors.coral,
  },
  eyebrow: {
    color: colors.coral,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.6,
  },
  title: {
    color: colors.ink,
    fontSize: 44,
    fontWeight: '900',
    letterSpacing: -1.8,
  },
});

// Este archivo exporta: GreetingCard (componente reutilizable).
// Se usa en: src/app/(tabs)/index.jsx.
// Importa de: constants/theme.js y React Native.
