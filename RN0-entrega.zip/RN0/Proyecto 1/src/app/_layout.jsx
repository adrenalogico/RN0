import { Stack } from 'expo-router';

// Declara el navegador raíz y entrega el control visual al grupo de tabs.
export default function RootLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}

// Este archivo exporta: RootLayout (layout raíz de Expo Router).
// Se usa en: automáticamente por Expo Router.
// Importa de: expo-router.
