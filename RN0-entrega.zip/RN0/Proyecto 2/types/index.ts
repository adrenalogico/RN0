import type { ReactNode } from 'react';

// Enumera los colores semánticos que consume toda la interfaz.
export type AppColors = {
  background: string;
  surface: string;
  surfaceElevated: string;
  text: string;
  textMuted: string;
  primary: string;
  primarySoft: string;
  accent: string;
  border: string;
  success: string;
  danger: string;
};

// Describe el tema resuelto a partir de la preferencia del sistema.
export type AppTheme = {
  isDark: boolean;
  colors: AppColors;
};

// Define las props comunes de cada tarjeta pedagógica.
export type ComponentShowcaseCardProps = {
  title: string;
  description: string;
  children: ReactNode;
  note?: string;
};

// Define las props del contenedor con scroll que comparten varias categorías.
export type ScreenContainerProps = {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
};

// Este archivo exporta: AppColors, AppTheme, ComponentShowcaseCardProps y ScreenContainerProps.
// Se usa en: constants/theme.ts, hooks/useAppTheme.ts y components/*.tsx.
// Importa de: React únicamente como tipo.
