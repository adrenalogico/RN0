import { StyleSheet, Text, View } from 'react-native';

import { spacing } from '../constants/theme';
import { useAppTheme } from '../hooks/useAppTheme';
import type { ComponentShowcaseCardProps } from '../types';

// Presenta nombre, explicación y demostración con la misma jerarquía visual.
export function ComponentShowcaseCard({
  title,
  description,
  children,
  note,
}: ComponentShowcaseCardProps) {
  const { colors, isDark } = useAppTheme();

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          boxShadow: isDark ? 'none' : '0 8px 18px rgba(17, 24, 39, 0.08)',
        },
      ]}>
      <View style={styles.headingRow}>
        <View style={[styles.marker, { backgroundColor: colors.primary }]} />
        <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
      </View>
      <Text style={[styles.description, { color: colors.textMuted }]}>{description}</Text>
      <View
        style={[
          styles.example,
          { backgroundColor: colors.surfaceElevated, borderColor: colors.border },
        ]}>
        {children}
      </View>
      {note ? <Text style={[styles.note, { color: colors.textMuted }]}>{note}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '100%',
    padding: spacing.md,
    borderWidth: 1,
    borderRadius: 22,
    elevation: 3,
  },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  marker: {
    width: 8,
    height: 22,
    borderRadius: 4,
  },
  title: {
    flex: 1,
    fontSize: 19,
    fontWeight: '800',
  },
  description: {
    marginTop: spacing.sm,
    fontSize: 14,
    lineHeight: 21,
  },
  example: {
    minHeight: 74,
    marginTop: spacing.md,
    padding: spacing.md,
    borderWidth: 1,
    borderRadius: 16,
    justifyContent: 'center',
  },
  note: {
    marginTop: spacing.sm,
    fontSize: 12,
    fontStyle: 'italic',
    lineHeight: 18,
  },
});

// Este archivo exporta: ComponentShowcaseCard (tarjeta reutilizable).
// Se usa en: todas las pantallas de categorías.
// Importa de: constants/theme.ts, hooks/useAppTheme.ts y types/index.ts.
