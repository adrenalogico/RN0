import { StatusBar } from 'expo-status-bar';
import { FlatList, SectionList, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ComponentShowcaseCard } from '../../../components/ComponentShowcaseCard';
import { spacing } from '../../../constants/theme';
import { useAppTheme } from '../../../hooks/useAppTheme';

const technologies = ['React', 'Expo', 'TypeScript', 'Router'];

const groupedComponents = [
  { title: 'Estructura', data: ['View', 'ScrollView', 'SafeAreaView'] },
  { title: 'Datos', data: ['FlatList', 'SectionList'] },
  { title: 'Feedback', data: ['Modal', 'ActivityIndicator', 'Alert'] },
];

// Usa SectionList como scroll principal y FlatList en sentido horizontal para evitar listas verticales anidadas.
export default function ListsScreen() {
  const { colors, isDark } = useAppTheme();

  return (
    <SafeAreaView
      style={[styles.safeArea, { backgroundColor: colors.background }]}
      edges={['top', 'left', 'right']}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <SectionList
        sections={groupedComponents}
        keyExtractor={(item, index) => `${item}-${index}`}
        stickySectionHeadersEnabled={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View style={styles.headerContent}>
            <View style={styles.header}>
              <Text style={[styles.eyebrow, { color: colors.primary }]}>03 · LISTAS</Text>
              <Text style={[styles.title, { color: colors.text }]}>Datos eficientes y ordenados</Text>
              <Text style={[styles.description, { color: colors.textMuted }]}>
                Las listas virtualizadas renderizan solo lo necesario y escalan mejor que un ScrollView largo.
              </Text>
            </View>

            <ComponentShowcaseCard
              title="FlatList"
              description="Renderiza una colección plana y extensa de forma eficiente. En esta demo se desplaza horizontalmente.">
              <FlatList
                horizontal
                data={technologies}
                keyExtractor={(item) => item}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
                renderItem={({ item, index }) => (
                  <View style={[styles.techItem, { backgroundColor: colors.primary }]}>
                    <Text style={styles.techNumber}>0{index + 1}</Text>
                    <Text style={styles.techName}>{item}</Text>
                  </View>
                )}
              />
            </ComponentShowcaseCard>

            <ComponentShowcaseCard
              title="SectionList"
              description="Agrupa elementos por secciones con encabezados. Conviene para contactos por letra, ajustes o catálogos."
              note="La lista agrupada que continúa debajo es la demostración real de este componente.">
              <Text style={[styles.demoPointer, { color: colors.text }]}>Mirá las categorías siguientes ↓</Text>
            </ComponentShowcaseCard>

            <View style={[styles.comparison, { backgroundColor: colors.primarySoft }]}>
              <Text style={[styles.comparisonText, { color: colors.text }]}>
                FlatList = datos planos · SectionList = datos agrupados
              </Text>
            </View>
          </View>
        }
        renderSectionHeader={({ section }) => (
          <Text style={[styles.sectionTitle, { color: colors.primary }]}>{section.title}</Text>
        )}
        renderItem={({ item }) => (
          <View style={[styles.row, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.rowDot, { backgroundColor: colors.accent }]} />
            <Text style={[styles.rowText, { color: colors.text }]}>{item}</Text>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  content: {
    width: '100%',
    maxWidth: 760,
    alignSelf: 'center',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    paddingBottom: 110,
  },
  headerContent: {
    gap: spacing.md,
  },
  header: {
    paddingHorizontal: spacing.xs,
    marginBottom: spacing.sm,
  },
  eyebrow: {
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
  },
  title: {
    marginTop: spacing.xs,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -1,
  },
  description: {
    marginTop: spacing.sm,
    fontSize: 15,
    lineHeight: 23,
  },
  horizontalList: {
    gap: spacing.sm,
  },
  techItem: {
    width: 116,
    height: 82,
    justifyContent: 'space-between',
    padding: spacing.sm,
    borderRadius: 14,
  },
  techNumber: {
    color: '#D9DAFF',
    fontSize: 11,
    fontWeight: '800',
  },
  techName: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '900',
  },
  demoPointer: {
    fontSize: 14,
    fontWeight: '800',
    textAlign: 'center',
  },
  comparison: {
    padding: spacing.md,
    borderRadius: 16,
  },
  comparisonText: {
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  sectionTitle: {
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.xs,
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
  },
  row: {
    minHeight: 52,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.md,
    borderWidth: 1,
    borderRadius: 15,
  },
  rowDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  rowText: {
    fontSize: 15,
    fontWeight: '700',
  },
});

// Este archivo exporta: ListsScreen (tab Listas).
// Se usa en: src/app/(tabs)/_layout.tsx por enrutamiento de archivos.
// Importa de: ComponentShowcaseCard, tema, hook, safe-area, Expo y React Native.
