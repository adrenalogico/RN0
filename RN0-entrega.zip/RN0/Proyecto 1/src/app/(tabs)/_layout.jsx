import Ionicons from '@expo/vector-icons/Ionicons';
import { Tabs } from 'expo-router';

import { colors } from '../../../constants/theme';

// Configura dos destinos inferiores, cada uno con un ícono reconocible.
export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.coral,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 12, fontWeight: '700' },
        tabBarStyle: {
          height: 68,
          paddingTop: 8,
          paddingBottom: 8,
          backgroundColor: colors.white,
          borderTopColor: colors.line,
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Inicio',
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? 'home' : 'home-outline'} size={23} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="estilos"
        options={{
          title: 'Estilos',
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? 'color-palette' : 'color-palette-outline'} size={23} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

// Este archivo exporta: TabsLayout (navegador inferior).
// Se usa en: automáticamente para las rutas del grupo (tabs).
// Importa de: expo-router, @expo/vector-icons y constants/theme.js.
